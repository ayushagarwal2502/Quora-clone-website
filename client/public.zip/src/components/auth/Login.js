import React from 'react'
import "./Login.css";
import {signInWithPopup} from 'firebase/auth'

const Login = () => {

  const handleSubmit=()=>{

  }
  return (
    <div className='login-container'>
        <div className='login-content'>
               <img src='' alt='' />
               <button onClick={handleSubmit} className='btn-btn-login'>Login to Continue</button>
        </div>
      
    </div>
  )
}

export default Login
